import tkinter as tk
from tkinter.ttk import Notebook
import requests
from tkinter import messagebox
class Translate(tk.Tk):

    def translate(self,target_language="iw",text=None):
        if not text:
            text = self.english_entry.get(1.0,tk.END)
        url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl={}&tl={}&dt=t&q={}".format("en",
                                                                                                           target_language,text)
        try:
            response= requests.get(url)
            response.raise_for_status()
            print(response.json())
            self.hebrew_translation.set(response.json()[0][0][0])
            messagebox.showinfo("Translated","Translation complete")
        except Exception as e:
            print(str(e))
            messagebox.showerror("Translation failed",str(e))
    def __init__(self):
        super().__init__()

        self.title("Translate")
        self.notebook = Notebook(self)
        self.notebook.pack(fill = tk.BOTH, expand = 1)

        english_tab = tk.Frame(self.notebook)

        self.english_entry = tk.Text(english_tab)
        self.english_entry.pack(side = tk.TOP, expand = 1)

        self.translate_button = tk.Button(english_tab, text="Translate",
            command = self.translate 
        )
        self.translate_button.pack(side = tk.BOTTOM, fill = tk.X)

        self.notebook.add(english_tab, text = "English")

        hebrew_tab = tk.Frame(self.notebook)
        self.notebook.add(hebrew_tab, text = "Hebrew")

        self.hebrew_translation = tk.StringVar(hebrew_tab)
        self.hebrew_translation.set("No Translation")

        self.hebrew_label = tk.Label(hebrew_tab, textvar = self.hebrew_translation)
        self.hebrew_label.pack(side = tk.TOP, fill = tk.BOTH, expand = 1)


if __name__ == "__main__":
    translate = Translate()
    translate.mainloop()